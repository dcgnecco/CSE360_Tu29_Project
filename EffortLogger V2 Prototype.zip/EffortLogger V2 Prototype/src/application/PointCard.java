/*package application;

public class PointCard extends Card {

}
*/