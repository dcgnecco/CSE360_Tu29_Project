/*package application;

public class SpecialCard extends Card{

}
*/